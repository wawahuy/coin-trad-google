export const appConfigs = {
  SYSTEM_TOKEN: (process.env.SYSTEM_TOKEN || "") as string,
  BASE_URL: (process.env.BASE_URL|| "") as string,
  BASE_SHELL_URL: (process.env.BASE_SHELL_URL|| "") as string,
}